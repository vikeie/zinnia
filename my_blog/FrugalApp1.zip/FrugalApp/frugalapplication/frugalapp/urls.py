from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings
from django.contrib.auth import views as auth_views
urlpatterns = [

    path('signup',views.signup,name='signup'),
    path('login',views.login_view,name='login'),
    path('logout',views.logout_view,name='logout'),
    path('',views.home,name='home'),
    path('Annonymous_user/<str:id>',views.Annonymous_user,name='Annonymous_user'),
    path('mydonations',views.my_donations,name='mydonations'),
    path('index/<str:pk_test>/',views.index,name='index'),
    path('ajax_addneed', views.ajax_addneed, name='ajax_addneed'),
    path('ajaxneed_edit/<int:id>', views.ajaxneed_edit, name='ajaxneed_edit'),
    path('needs_details',views.needs_details,name='needs_details'),
    path('add_activity',views.add_activity,name='add_activity'),
    path('activity_details',views.activity_details,name='activity_details'),
    path('profile',views.ngo_profile,name='profile'),
    path('profile_update',views.Profile_update,name='profile_update'),
    path('activate/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/',
         views.activate, name='activate'),
    path('lazy_load_posts/', views.lazy_load_posts, name='lazy_load_posts'),

]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)