from django.apps import AppConfig


class FrugalappConfig(AppConfig):
    name = 'frugalapp'
