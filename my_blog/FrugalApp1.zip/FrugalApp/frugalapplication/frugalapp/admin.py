from django.contrib import admin
from .models import NGO,Needs,Activity,Category_needs,Donation
# Register your models here.

admin.site.register(NGO)
admin.site.register(Needs)
admin.site.register(Activity)
admin.site.register(Category_needs)
admin.site.register(Donation)