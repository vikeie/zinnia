from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.contrib.auth.decorators import login_required
from .forms import Signup_form,ngo_profile_form,needs_form,activity_form,Profile_update_form,Donation_form
from .models import NGO,Needs,Activity,Donation
from .models import User
from django.contrib.auth import logout
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.template import loader
# Create your views here.
from .tokens import account_activation_token


def signup(request):
    if request.method == 'POST':
        form = Signup_form(request.POST)
        forms = ngo_profile_form(request.POST,request.FILES)
        if form.is_valid() and forms.is_valid():
            user,profile = form.save(),forms.save(commit=False)
            profile.user = user
            profile.save()
            subject = 'Activate Your Frugal app N.G.O account'
            message = render_to_string('acc_active_email.html', {
                'user': user,
                'domain': 'localhost:8000',
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': account_activation_token.make_token(user),
            })
            user.email_user(subject, message)
            messages.add_message(request, messages.INFO, 'Verify your email id')
        return redirect('login')

    else:
        form = Signup_form
        forms = ngo_profile_form
        return render(request,'signup.html',{'form':form,'forms':forms})



def activate(request, uidb64, token):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None and account_activation_token.check_token(user, token):

        user.is_active = True
        user.ngo.email_verification = True
        user.save()
        user.ngo.save()
        messages.add_message(request, messages.INFO, 'Your Email id verified')
        return redirect('home')
    else:
        return HttpResponse('Invalid Token')

def login_view(request):
    if request.method=='POST':
        userinput = request.POST['username']
        try:
            username = NGO.objects.get(mobile=userinput).user

        except NGO.DoesNotExist:
            try:

                username = User.objects.get(email=userinput).username

            except User.DoesNotExist:
                username = request.POST['username']
                print(username)






            # username = NGO.objects.get(mobile=userinput).user



        password = request.POST['password']



        user = authenticate(username=username,password=password)
        if user is not None:
            if user.is_active and user.ngo.email_verification== True and user.ngo.is_approved== True :

                login(request, user)
                return redirect('home')
            else:
                return HttpResponse('your account is not active ')
        else:

            return render(request,'login.html',{})
    else:
        return render(request, 'login.html', {})

def home(request):
    needs = Needs.objects.order_by('-date')[:5]
    return render(request,'home.html',{'posts':needs})


@login_required(login_url='login')
def needs_details(request):
        form = needs_form
        ngo_needs = Needs.objects.filter(ngo= request.user.ngo)
        return render(request,'needs_details.html',{'ngo_needs':ngo_needs,'form':form})
def ajax_addneed(request):
    output = dict()
    form= needs_form(request.POST)
    if form.is_valid():
        ngos=form.save()
        ngos.ngo = request.user.ngo
        ngos.save()
        ngo_needs = Needs.objects.filter(ngo= request.user.ngo)
        output['ng']= render_to_string('ajax_need_create.html',{'ngo_needs':ngo_needs})
        output['message'] = 'Needs Added'
    return JsonResponse(output)
def ajaxneed_edit(request,id):
    output = dict()
    ngo_needs = Needs.objects.get(id=id)
    if request.method == 'POST':
        form = needs_form(request.POST,instance=ngo_needs)
        if form.is_valid():
            ngo = form.save()
            ngo.ngo = request.user.ngo
            ngo.save()
            ngo_needs = Needs.objects.filter(ngo= request.user.ngo)
            output['ngs']= render_to_string('ajaxneed_edit.html',{'ngo_needs':ngo_needs})
            output['messages']='edit updated successfully'
            return JsonResponse(output)
    else:
        form = needs_form(instance=ngo_needs)
        output['form']=render_to_string('ajax_form.html',{'form':form,'ngo':id},request=request)
        return JsonResponse(output)




@login_required(login_url='login')
def add_activity(request):
    if request.method == 'POST':
        form = activity_form(request.POST)
        if form.is_valid():
            activity = form.save()
            activity.ngo = request.user.ngo
            activity.save()
            return redirect('activity_details')
    else:
        form = activity_form
        return render(request,'add_activity.html',{'activity': form})

@login_required(login_url='login')
def activity_details(request):
    activity = Activity.objects.filter(ngo= request.user.ngo)
    return render(request,'activity_detail.html',{'form':activity})

@login_required(login_url='login')
def ngo_profile(request):
    ngo= NGO.objects.filter(user = request.user)
    return render(request,'profile.html',{'ngo':ngo})


@login_required(login_url='login')
def logout_view(request):
    logout(request)
    return render(request,'logout.html')

def Profile_update(request):
    if request.method == 'POST':
        form= Profile_update_form(request.POST,request.FILES,instance=request.user.ngo)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = Profile_update_form(instance=request.user.ngo)
        return render(request,'profile_edit.html',{'form':form})

def index(request,pk_test):


    g = Needs.objects.filter(id=pk_test)

    return render(request, 'indexpage.html', {'g':g})



def lazy_load_posts(request):
    page = request.POST.get('page')
    posts = Needs.objects.order_by('-date')[5:]
    # use Django's pagination
    # https://docs.djangoproject.com/en/dev/topics/pagination/
    results_per_page = 5
    paginator = Paginator(posts, results_per_page)
    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        posts = paginator.page(1)
    except EmptyPage:
        posts = paginator.page(paginator.num_pages)
    # build a html posts list with the paginated posts
    posts_html = loader.render_to_string(
        'index.html',
        {'posts': posts}
    )
    # package output data and return it as a JSON object
    output_data = {
        'posts_html': posts_html,
        'has_next': posts.has_next()
    }
    return JsonResponse(output_data)

def Annonymous_user(request,id):

    if request.method == 'POST':
        form = Donation_form(request.POST,request.FILES)
        if form.is_valid():
            activity = form.save()
            activity.needs.ngo = request.user.needs.ngo
            activity.save()

    else:


        form = Donation_form
        return render(request,'donation.html',{'form':form})
def my_donations(request):
    donations = Donation.objects.filter(needs = request.needs.user.ngo)
    return render(request,'mydonations.html',{'donations':donations})