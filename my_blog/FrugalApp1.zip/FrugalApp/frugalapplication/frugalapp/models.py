from django.db import models
from django.contrib.auth.models import User
# Create your models here.

status_choice = (('P','posted'),('A','accepted'),('D','denied'))
class NGO(models.Model):
    user= models.OneToOneField(User,on_delete=models.CASCADE, null = True)
    image = models.ImageField(default='default.jpg',upload_to='mypics', null=True)
    mobile = models.CharField(max_length=12)
    about = models.TextField(null = True,blank=True)
    website = models.CharField(max_length=100,null=True,blank=True)
    is_approved = models.BooleanField(null=True, blank=True)
    email_verification = models.BooleanField(default=False)





class Activity(models.Model):
    ngo = models.ForeignKey(NGO, on_delete= models.CASCADE,  null = True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    title = models.CharField(max_length=30)
    date = models.DateTimeField()
    place = models.CharField(max_length=30)
    description = models.TextField()

class Category_needs(models.Model):
    category_needs = models.CharField(max_length=30)

    def __str__(self):
        return self.category_needs

class Needs(models.Model):
    ngo = models.ForeignKey(NGO, on_delete= models.CASCADE,  null = True)

    item_name = models.CharField(max_length=30)
    categories = models.ForeignKey(Category_needs, on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now_add=True)
    quantity = models.IntegerField()
    description = models.TextField()

class Donation(models.Model):
    name = models.CharField(max_length=30)
    needs = models.ForeignKey(Needs, on_delete=models.CASCADE,  null = True)
    address = models.TextField()
    quantity = models.IntegerField()
    mobile = models.CharField(max_length=12)
    image = models.ImageField(upload_to='mypictures', null=True)
    status = models.CharField(max_length=1, choices=status_choice,default='P')
    email = models.EmailField()
    description = models.TextField()

