from .models import NGO,Needs,Activity,Donation
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django import forms


class Signup_form(UserCreationForm):
    class Meta:
        model = User
        fields = ('username','first_name','last_name','password1','password2','email')

class ngo_profile_form(forms.ModelForm):
    class Meta:
        model = NGO
        exclude = ['is_approved','about','website','image','user','email_verification']

class needs_form(forms.ModelForm):
    class Meta:
        model = Needs
        exclude = ['ngo','user']

class activity_form(forms.ModelForm):
    class Meta:
        model = Activity
        exclude = ['ngo', 'user']

class Profile_update_form(forms.ModelForm):
    class Meta:
        model = NGO
        fields = ['image','mobile','about']


class Donation_form(forms.ModelForm):
    class Meta:
        model = Donation
        exclude = ['needs','status']


